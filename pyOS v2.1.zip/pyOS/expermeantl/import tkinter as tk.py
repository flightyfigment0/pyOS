
import tkinter as tk
from tkinter import scrolledtext, messagebox
import os
import datetime
import webbrowser

# Path for users and permissions
USER_FILE = r"A:\pyOS\os\users.txt"
PERMISSIONS_FILE = r"A:\pyOS\os\userpermissions.txt"

def load_users():
    users = {}
    try:
        with open(PERMISSIONS_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if ':' in line:
                    user, role = line.split(':')
                    users[user] = role
    except FileNotFoundError:
        open(PERMISSIONS_FILE, 'w').close()
    return users

class PyOSApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("pyOS GUI")
        self.geometry("700x500")
        self.users = load_users()
        self.current_user = None
        self.current_role = None
        self.create_login_screen()

    def create_login_screen(self):
        self.clear_widgets()

        tk.Label(self, text="pyOS Login", font=("Arial", 18)).pack(pady=20)
        tk.Label(self, text="Username:").pack()

        self.username_entry = tk.Entry(self)
        self.username_entry.pack(pady=5)

        self.login_btn = tk.Button(self, text="Login", command=self.attempt_login)
        self.login_btn.pack(pady=10)

    def clear_widgets(self):
        for widget in self.winfo_children():
            widget.destroy()

    def attempt_login(self):
        username = self.username_entry.get().strip()
        if not username:
            messagebox.showwarning("Input Error", "Please enter a username.")
            return
        if username in self.users:
            self.current_user = username
            self.current_role = self.users[username]
            messagebox.showinfo("Welcome", f"Welcome {username}! Role: {self.current_role}")
            self.create_main_screen()
        else:
            messagebox.showerror("Login Failed", "User not found.")

    def create_main_screen(self):
        self.clear_widgets()

        top_frame = tk.Frame(self)
        top_frame.pack(fill='x')

        tk.Label(top_frame, text=f"Logged in as: {self.current_user} ({self.current_role})", font=("Arial", 12)).pack(side='left', padx=10, pady=10)
        logout_btn = tk.Button(top_frame, text="Logout", command=self.logout)
        logout_btn.pack(side='right', padx=10)

        self.output_box = scrolledtext.ScrolledText(self, height=20, state='disabled', font=("Consolas", 11))
        self.output_box.pack(fill='both', expand=True, padx=10, pady=5)

        self.cmd_entry = tk.Entry(self, font=("Consolas", 12))
        self.cmd_entry.pack(fill='x', padx=10, pady=5)
        self.cmd_entry.bind('<Return>', self.execute_command)

        self.print_output("Type 'help' for command list.\n")

    def logout(self):
        self.current_user = None
        self.current_role = None
        self.create_login_screen()

    def print_output(self, text):
        self.output_box.configure(state='normal')
        self.output_box.insert(tk.END, text + '\n')
        self.output_box.configure(state='disabled')
        self.output_box.see(tk.END)

    def execute_command(self, event=None):
        cmd = self.cmd_entry.get().strip()
        self.cmd_entry.delete(0, tk.END)
        if not cmd:
            return
        self.print_output(f"pyOS {self.current_user}> {cmd}")

        # Basic commands implementation, expand as needed
        if cmd.lower() in ('help', '?'):
            self.print_output(self.get_command_list())
        elif cmd.lower() == 'time':
            now = datetime.datetime.now().strftime("%H:%M:%S")
            self.print_output(f"Current time: {now}")
        elif cmd.lower() == 'clear' or cmd.lower() == 'cls':
            self.output_box.configure(state='normal')
            self.output_box.delete('1.0', tk.END)
            self.output_box.configure(state='disabled')
        elif cmd.startswith('open'):
            app = cmd.split(' ')[-1]
            self.open_app(app)
        elif cmd == 'exit':
            self.destroy()
        else:
            self.print_output("Command not recognized.")

    def get_command_list(self):
        return """
Available Commands:
help / ?          - Show this help
time              - Show current time
clear / cls       - Clear output
open <app>        - Open app (notepad, browser, files)
exit              - Exit pyOS GUI
"""

    def open_app(self, app_name):
        supported = {
            'notepad': "notepad.exe",
            'browser': "msedge.exe",
            'files': "explorer.exe",
            'taskmanager': "Taskmgr.exe",
        }
        if app_name in supported:
            try:
                os.system(supported[app_name])
                self.print_output(f"Opening {app_name}...")
            except Exception as e:
                self.print_output(f"Failed to open {app_name}: {e}")
        else:
            self.print_output(f"Unsupported app: {app_name}")

if __name__ == "__main__":
    app = PyOSApp()
    app.mainloop()
