import tkinter as tk
from tkinter import messagebox, simpledialog

PERMISSION_FILE = r"A:\pyOS\os\userpermissions.txt"

def load_users():
    users = []
    try:
        with open(PERMISSION_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if ':' in line:
                    user, role = line.split(':')
                    users.append((user, role))
                elif line:
                    users.append((line, "[INVALID]"))
    except FileNotFoundError:
        open(PERMISSION_FILE, 'w').close()  # Create empty file
    return users

def save_users(users):
    with open(PERMISSION_FILE, 'w') as f:
        for user, role in users:
            f.write(f"{user}:{role}\n")

def refresh_list():
    listbox.delete(0, tk.END)
    for user, role in load_users():
        listbox.insert(tk.END, f"{user} - {role}")

def add_user():
    name = simpledialog.askstring("New User", "Enter username:")
    if not name:
        return
    role = simpledialog.askstring("New User", "Enter role (admin/user):")
    if role not in ['admin', 'user']:
        messagebox.showerror("Invalid Role", "Role must be 'admin' or 'user'")
        return
    users = load_users()
    users.append((name, role))
    save_users(users)
    refresh_list()

def update_user():
    selected = listbox.curselection()
    if not selected:
        return
    index = selected[0]
    users = load_users()
    username, _ = users[index]
    new_role = simpledialog.askstring("Update Role", f"New role for {username} (admin/user):")
    if new_role not in ['admin', 'user']:
        messagebox.showerror("Invalid Role", "Role must be 'admin' or 'user'")
        return
    users[index] = (username, new_role)
    save_users(users)
    refresh_list()

def delete_user():
    selected = listbox.curselection()
    if not selected:
        return
    index = selected[0]
    users = load_users()
    confirm = messagebox.askyesno("Delete", f"Delete user {users[index][0]}?")
    if confirm:
        users.pop(index)
        save_users(users)
        refresh_list()

# --- GUI setup ---
root = tk.Tk()
root.title("pyOS User Manager")

listbox = tk.Listbox(root, width=40, height=15)
listbox.pack(padx=10, pady=10)

btn_frame = tk.Frame(root)
btn_frame.pack(pady=5)

tk.Button(btn_frame, text="Add User", command=add_user).grid(row=0, column=0, padx=5)
tk.Button(btn_frame, text="Update Role", command=update_user).grid(row=0, column=1, padx=5)
tk.Button(btn_frame, text="Delete User", command=delete_user).grid(row=0, column=2, padx=5)

refresh_list()
root.mainloop()
